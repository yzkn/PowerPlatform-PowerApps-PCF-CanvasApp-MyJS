/*! For license information please see bundle.js.LICENSE.txt */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;(()=>{"use strict";var t={};(()=>{var e=t;Object.defineProperty(e,"__esModule",{value:!0}),e.MyJs=void 0;var o=function(){function t(){this.outputs={outArgument1:void 0,outArgument2:void 0}}return t.prototype.init=function(t,e,o,u){this.notifyOutputChanged=e},t.prototype.updateView=function(t){console.debug("MyJs:updateView");var e="";if(t.parameters.jscode){e="Debug:\n".concat((new Date).toLocaleTimeString(),"\n").concat(JSON.stringify({in1:t.parameters.inArgument1,in2:t.parameters.inArgument2}));try{var o=Function(t.parameters.jscode.raw)(t.parameters.inArgument1.raw,t.parameters.inArgument2.raw);o.out1&&(this.outputs.outArgument1=o.out1),o.out2&&(this.outputs.outArgument2=o.out2)}catch(t){e="Error:".concat(t.message,"\n").concat(e)}this.outputs.debug=e,this.notifyOutputChanged()}},t.prototype.getOutputs=function(){return console.debug("MyJs:getOutputs"),this.outputs},t.prototype.destroy=function(){console.debug("MyJs:destroy")},t}();e.MyJs=o})(),pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad=t})();
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('YA.MyJs', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.MyJs);
} else {
	var YA = YA || {};
	YA.MyJs = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.MyJs;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}